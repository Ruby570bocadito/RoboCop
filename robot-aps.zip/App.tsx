import React, { useState, useRef, useEffect } from 'react';
import { RobotPlatform, HistoryItem } from './types';
import { DEFAULT_PROMPT, PLATFORM_DESCRIPTIONS } from './constants';
import { generateRobotCodeStream } from './services/geminiService';
import { CodeBlock } from './components/CodeBlock';
import { Icons } from './components/IconComponents';

const App: React.FC = () => {
  const [platform, setPlatform] = useState<RobotPlatform>(RobotPlatform.ARDUINO);
  const [prompt, setPrompt] = useState<string>(DEFAULT_PROMPT);
  const [generatedCode, setGeneratedCode] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  // Auto-scroll logic could go here, but pure CSS often handles it well enough for code blocks
  
  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsLoading(true);
    setGeneratedCode(''); // Clear previous code
    
    // Close history if open on mobile
    setShowHistory(false);

    try {
      const fullCode = await generateRobotCodeStream(platform, prompt, (chunk) => {
        setGeneratedCode(chunk);
      });

      // Save to history
      const newItem: HistoryItem = {
        id: Date.now().toString(),
        platform,
        prompt,
        code: fullCode,
        timestamp: Date.now()
      };
      
      setHistory(prev => [newItem, ...prev].slice(0, 10)); // Keep last 10
    } catch (error) {
      console.error("Generation failed", error);
      setGeneratedCode("// Error generating code. Please try again or check your API configuration.");
    } finally {
      setIsLoading(false);
    }
  };

  const loadFromHistory = (item: HistoryItem) => {
    setPlatform(item.platform);
    setPrompt(item.prompt);
    setGeneratedCode(item.code);
    setShowHistory(false);
  };

  return (
    <div className="min-h-screen bg-cyber-900 text-gray-100 font-sans selection:bg-cyber-500/30 selection:text-cyber-200">
      
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 h-16 bg-cyber-900/80 backdrop-blur-md border-b border-cyber-700 z-50 flex items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-cyber-500 to-blue-600 rounded-lg shadow-lg shadow-cyber-500/20">
            <Icons.Bot className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
            Robot APS
          </h1>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className="md:hidden p-2 hover:bg-cyber-800 rounded-lg text-gray-400 hover:text-white transition-colors"
          >
            <Icons.History className="w-5 h-5" />
          </button>
          <div className="hidden md:flex items-center text-xs text-cyber-500 font-mono bg-cyber-500/10 px-3 py-1 rounded-full border border-cyber-500/20">
            v1.0.0 • SYSTEM ACTIVE
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 pb-12 px-4 md:px-8 max-w-7xl mx-auto h-[calc(100vh-1rem)]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full">
          
          {/* Left Column: Input & Configuration */}
          <div className="lg:col-span-5 flex flex-col gap-6 h-full overflow-y-auto pb-20 lg:pb-0 no-scrollbar">
            
            <div className="space-y-6">
              {/* Introduction */}
              <div>
                <h2 className="text-2xl font-bold text-white mb-2">Program your robot</h2>
                <p className="text-gray-400 text-sm leading-relaxed">
                  Describe the behavior you want, select your hardware platform, and let the AI generate the optimal control code.
                </p>
              </div>

              {/* Platform Selector */}
              <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-wider text-cyber-500 flex items-center gap-2">
                  <Icons.Cpu className="w-4 h-4" /> Hardware Platform
                </label>
                <div className="relative">
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value as RobotPlatform)}
                    className="w-full bg-cyber-800 text-white border border-cyber-700 rounded-lg px-4 py-3 appearance-none focus:outline-none focus:ring-2 focus:ring-cyber-500 focus:border-transparent transition-all"
                  >
                    {Object.values(RobotPlatform).map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/></svg>
                  </div>
                </div>
                <p className="text-xs text-gray-500 px-1">
                  {PLATFORM_DESCRIPTIONS[platform]}
                </p>
              </div>

              {/* Prompt Input */}
              <div className="space-y-2 flex-1 flex flex-col">
                <label className="text-xs font-semibold uppercase tracking-wider text-cyber-500 flex items-center gap-2">
                  <Icons.Terminal className="w-4 h-4" /> Instructions
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="E.g., Move the servo on pin 9 to 180 degrees when the button on pin 2 is pressed..."
                  className="w-full h-48 lg:h-64 bg-cyber-800 text-gray-200 border border-cyber-700 rounded-lg p-4 resize-none focus:outline-none focus:ring-2 focus:ring-cyber-500 focus:border-transparent transition-all font-mono text-sm leading-relaxed"
                />
              </div>

              {/* Action Button */}
              <button
                onClick={handleGenerate}
                disabled={isLoading || !prompt.trim()}
                className={`w-full py-4 rounded-lg font-bold text-sm uppercase tracking-widest transition-all transform flex items-center justify-center gap-3 shadow-lg ${
                  isLoading
                    ? 'bg-cyber-800 text-gray-500 cursor-not-allowed border border-cyber-700'
                    : 'bg-gradient-to-r from-cyber-500 to-blue-600 text-white hover:from-cyber-400 hover:to-blue-500 hover:shadow-cyber-500/25 active:scale-[0.98]'
                }`}
              >
                {isLoading ? (
                  <>
                    <Icons.Zap className="w-5 h-5 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Icons.Play className="w-5 h-5 fill-current" />
                    Generate Code
                  </>
                )}
              </button>
            </div>

            {/* Desktop History (visible on lg screens) */}
            <div className="hidden lg:block mt-8 border-t border-cyber-700 pt-6">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-4 flex items-center gap-2">
                <Icons.History className="w-4 h-4" /> Recent Generations
              </h3>
              <div className="space-y-3">
                {history.length === 0 ? (
                  <p className="text-xs text-gray-600 italic">No history yet.</p>
                ) : (
                  history.map((item) => (
                    <div 
                      key={item.id}
                      onClick={() => loadFromHistory(item)}
                      className="group p-3 rounded-lg bg-cyber-800/50 hover:bg-cyber-800 border border-transparent hover:border-cyber-600 cursor-pointer transition-all"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-mono text-cyber-400 px-1.5 py-0.5 rounded bg-cyber-500/10 border border-cyber-500/20">
                          {item.platform.split(' ')[0]}
                        </span>
                        <span className="text-[10px] text-gray-500">
                          {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-xs text-gray-300 line-clamp-2 group-hover:text-white transition-colors">
                        {item.prompt}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Output Code */}
          <div className="lg:col-span-7 h-[500px] lg:h-full flex flex-col">
            <CodeBlock 
              code={generatedCode} 
              language={platform.includes('Python') ? 'python' : 'cpp'} 
              isLoading={isLoading} 
            />
          </div>

        </div>
      </main>

      {/* Mobile History Drawer/Modal */}
      {showHistory && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowHistory(false)}></div>
          <div className="absolute right-0 top-0 bottom-0 w-3/4 max-w-sm bg-cyber-900 border-l border-cyber-700 p-6 overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-white">History</h3>
              <button onClick={() => setShowHistory(false)} className="text-gray-400 hover:text-white">
                <Icons.Trash className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              {history.map((item) => (
                <div 
                  key={item.id}
                  onClick={() => loadFromHistory(item)}
                  className="p-4 rounded-lg bg-cyber-800 border border-cyber-700 active:bg-cyber-700"
                >
                   <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono text-cyber-400">
                      {item.platform.split(' ')[0]}
                    </span>
                    <span className="text-xs text-gray-500">
                      {new Date(item.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-300 line-clamp-3">
                    {item.prompt}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default App;