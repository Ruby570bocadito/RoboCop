import { RobotPlatform } from './types';

export const DEFAULT_PROMPT = "Make the robot move forward for 5 seconds, then turn left 90 degrees, and stop if it detects an obstacle within 20cm.";

export const PLATFORM_DESCRIPTIONS: Record<RobotPlatform, string> = {
  [RobotPlatform.ARDUINO]: "Best for microcontrollers like Uno, Nano, and Mega using standard Servo/Motor libraries.",
  [RobotPlatform.ESP32]: "Ideal for IoT robots using MicroPython.",
  [RobotPlatform.RASPBERRY_PI]: "For robots using a Pi with standard GPIO libraries like gpiozero or RPi.GPIO.",
  [RobotPlatform.ROS2]: "Enterprise-grade robotics middleware using rclpy.",
  [RobotPlatform.GENERIC_PYTHON]: "Standard Python scripts for logic or simulation.",
  [RobotPlatform.GENERIC_CPP]: "Standard C++ logic without hardware specifics.",
};
