import React from 'react';
import { 
  Cpu, 
  Code2, 
  Terminal, 
  Zap, 
  Bot, 
  Copy, 
  Check, 
  Play, 
  Trash2,
  History
} from 'lucide-react';

export const Icons = {
  Cpu,
  Code: Code2,
  Terminal,
  Zap,
  Bot,
  Copy,
  Check,
  Play,
  Trash: Trash2,
  History
};
