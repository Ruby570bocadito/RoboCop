import React, { useState } from 'react';
import { Icons } from './IconComponents';

interface CodeBlockProps {
  code: string;
  language: string;
  isLoading: boolean;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({ code, language, isLoading }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (!code) return;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-cyber-800 rounded-xl border border-cyber-700 shadow-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-cyber-900 border-b border-cyber-700">
        <div className="flex items-center gap-2">
          <Icons.Code className="w-5 h-5 text-cyber-500" />
          <span className="text-sm font-mono text-gray-300 font-bold">{language} Output</span>
        </div>
        <button
          onClick={handleCopy}
          disabled={isLoading || !code}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
            copied
              ? 'bg-green-500/20 text-green-400'
              : 'bg-cyber-700 hover:bg-cyber-600 text-gray-300'
          }`}
        >
          {copied ? <Icons.Check className="w-4 h-4" /> : <Icons.Copy className="w-4 h-4" />}
          {copied ? 'Copied!' : 'Copy Code'}
        </button>
      </div>

      {/* Code Area */}
      <div className="relative flex-1 overflow-hidden">
        {isLoading && !code && (
          <div className="absolute inset-0 flex items-center justify-center bg-cyber-800/80 z-10">
            <div className="flex flex-col items-center gap-3">
              <Icons.Zap className="w-10 h-10 text-cyber-500 animate-pulse" />
              <span className="text-cyber-400 font-mono text-sm animate-pulse">Generating logic matrix...</span>
            </div>
          </div>
        )}
        
        <pre className="w-full h-full p-6 overflow-auto text-sm font-mono leading-relaxed text-gray-300 bg-[#0d1117]">
          <code>
            {code || "// Ready to generate. Describe your robot's task on the left."}
          </code>
        </pre>
      </div>
    </div>
  );
};
