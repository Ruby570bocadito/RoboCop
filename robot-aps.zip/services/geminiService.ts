import { GoogleGenAI } from "@google/genai";
import { RobotPlatform } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateRobotCodeStream = async (
  platform: RobotPlatform,
  userPrompt: string,
  onChunk: (text: string) => void
): Promise<string> => {
  const model = "gemini-2.5-flash";

  const systemInstruction = `
    You are an expert robotics software engineer. Your task is to generate functional, efficient, and well-commented code for robots based on natural language instructions.
    
    Rules:
    1. Output ONLY the code block. Do not wrap it in markdown code fences (like \`\`\`cpp). I will handle the rendering.
    2. Include comments explaining key parts of the logic.
    3. Assume standard library wiring for common components (e.g., Servo on pin 9, Ultrasonic Trigger on 12, Echo on 11) unless specified otherwise, but define these as constants at the top so they are easy to change.
    4. Handle edge cases where possible (e.g., safety stops).
    
    Target Platform: ${platform}
  `;

  const finalPrompt = `
    User Requirement: "${userPrompt}"
    
    Generate the complete code file for the "${platform}" platform.
  `;

  try {
    const responseStream = await ai.models.generateContentStream({
      model: model,
      contents: finalPrompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.2, // Low temperature for more deterministic code
      },
    });

    let fullText = "";
    for await (const chunk of responseStream) {
      const text = chunk.text;
      if (text) {
        fullText += text;
        onChunk(fullText);
      }
    }
    
    // Cleanup any markdown code fences if the model ignores the instruction (failsafe)
    return fullText.replace(/^```[a-z]*\n/i, '').replace(/\n```$/, '');
  } catch (error) {
    console.error("Error generating code:", error);
    throw error;
  }
};
