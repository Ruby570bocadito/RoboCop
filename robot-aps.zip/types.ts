export enum RobotPlatform {
  ARDUINO = 'Arduino (C++)',
  ESP32 = 'ESP32 (MicroPython)',
  RASPBERRY_PI = 'Raspberry Pi (Python GPIO)',
  ROS2 = 'ROS 2 (Python)',
  GENERIC_PYTHON = 'Generic Python',
  GENERIC_CPP = 'Generic C++'
}

export interface CodeGenerationConfig {
  platform: RobotPlatform;
  prompt: string;
  includeComments: boolean;
}

export interface HistoryItem {
  id: string;
  platform: RobotPlatform;
  prompt: string;
  code: string;
  timestamp: number;
}
